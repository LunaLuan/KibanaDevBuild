# from nltk.corpus import jeita

# tagged_sents = jeita.tagged_sents()
dictionary = set()

# file_dictionary = 'dictionary.txt'

def wordSegmentation(sentence, dictionary):
    path = []
    next = []

    lenSentence = len(sentence)

    for startNode in range(lenSentence):
        path.append({})
        next.append({})

        for endNode in range(startNode, lenSentence):
            word = sentence[startNode: endNode + 1]
            if word in dictionary:
                path[startNode][endNode] = 1
                next[startNode][endNode] = set()
            else:
                path[startNode][endNode] = 200000000
                next[startNode][endNode] = set()

                # if startNode != endNode:
                #     next[]

    for startNode in range(lenSentence):
        for endNode in range(startNode, lenSentence):
            for nextNode in range(startNode, endNode):
                path1 = path[startNode][nextNode]
                path2 = path[nextNode + 1][endNode]

                if (path1 + path2) < path[startNode][endNode]:
                    path[startNode][endNode] = (path1 + path2)

                    if next[startNode][endNode] == None:
                        next[startNode][endNode] = set()
                        next[startNode][endNode].add(nextNode)

                if (path1 + path2) == path[startNode][endNode]:
                    next[startNode][endNode].add(nextNode)
    print (path)
    print (next)
    
    print (path[0][lenSentence - 1])
    findNextNode(path, next, 0, lenSentence - 1)

def findNextNode(path, next, startNode, endNode):
    for nextNode in next[startNode][endNode]:
        if path[startNode][nextNode] == 1:
            print (startNode, nextNode)
        else:
            findNextNode(path, next, startNode, nextNode)

        if path[nextNode + 1][endNode] == 1:
            print (nextNode + 1, endNode)
        else:
            findNextNode(path, next, nextNode + 1, endNode)
    





# for word in jeita.words():
#     dictionary.add(word)
#     print (word)
#
#
#
# for tagged_sent in jeita.tagged_sents():





