import test

sentenceFile = 'sentences2.txt'
dictionaryFile = 'dictionary2.txt'

sentences = []
dictionary = set()

with open(sentenceFile) as fin:
    for line in fin:
        sentences.append(line[0: len(line) - 1])

with open(dictionaryFile) as fin:
    for line in fin:
        dictionary.add(line[0: len(line) - 1])

print (sentences)
print (dictionary)
for line in sentences:
    test.wordSegmentation(line, dictionary)

        